
//Function For Selecting Module Based On Domain Choosed
function getModules() {
    var domains = document.getElementById("chooseDomain");
    var modules = document.getElementById("chooseModule");

    var selectedDomain = domains.options[domains.selectedIndex].value;
    console.log(domains, '', modules, '', selectedDomain);
    if (selectedDomain == "JEE") {
       modules.options.length = 0;
        modules.options[0] = new Option("Select", "Select");
        modules.options[1] = new Option("Core Java","core java");
        modules.options[2] = new Option("Servlet-Jsp", "Servlet-Jsp");
        modules.options[3] = new Option("Spring", "Spring");
    }
    else if (selectedDomain == ".NET") {
        modules.options.length = 0;
        modules.options[0] = new Option("Select", "Select");
        modules.options[1] = new Option("C#", "C#");
        modules.options[2] = new Option("ADO.NET", "ADO.NET");
        modules.options[3] = new Option("ASP.NET", "ASP.NET");
    } else {
        modules.options.length = 0;
        modules.options[0] = new Option("Select", "Select");
    }
}//end of the function

//function to display total marks
function moduleScore(frmMSC) {
    if (frmMSC.checkValidity()) {
        var name = frmMSC.txtEmpName.value;
        var mtp = parseInt(frmMSC.mptMarks.value);
        var mtt = parseInt(frmMSC.mttMarks.value);
        var ast = parseInt(frmMSC.assignMarks.value);
        var result = (mtp) + (mtt) + (ast);
        var details = "Employee Name:" + name + "\nMTP Marks=" + mtp + "\nMTT Marks=" + mtt + "\nAssignment Marks=" + ast + "\nTotal Marks=" + result;
        alert(details);
    }
}