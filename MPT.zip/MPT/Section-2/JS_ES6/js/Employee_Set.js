//Creating Parent Class Login
class Login {
    getLogin() {
        return "getLogin() function of Login class";
    }
    getLogout() {
        return "getLogout()function of Logout Class;"
    }
}//end Of Login Class


//Creating Employee Class
class Employee {
    getLogin() {
        return "getLogin() function of Employee Class";
    }
    getLogout() {
        return "getLogout() function of Employee Class";
    }
    constructor(empId, empName, empSalary, empDesignation) {
        this._empId_ = empId;
        this._empName_ = empName;
        this._empSalary_ = empSalary;
        this._empDesignation_ = empDesignation;
    }

    //ReadAnd Write Properties-get(),set()
    //get() &set() of empId
    get empId() {
        return this._empId_;
    }
    set empId(empId) {
        this._empId_ = empId;
    }
    //get() & set() of empName
    get empName() {
        return this._empName_;
    }
    set empName(empName) {
        this._empName_ = empName;
    }
    //get() & set() of empSalary
    get empSalary() {
        return this._empSalary_;
    }
    set empSalary(empSalary) {
        this._empSalary_ = empSalary;
    }
    //get() & set() of empDesignation
    get empDesignation() {
        return this._empDesignation_;
    }
    set empDesignation(empDesignation) {
        this._empDesignation_ = empDesignation;
    }

    //function printDetails()-To print All Details Of employees
    printDetails() {
        let details = `Employee Details Are 
           Employee Id is ${this._empId_}
           Employee Name is${this._empName_}
           Employee Salary is${this._empSalary_}
           Employee Designation is${this._empDesignation_} `;
        return details;
    }
}//end of Employee Class

//Creating EmployeeUtility Class
class EmployeeUtility {
    constructor() {
        let empObj1 = new Employee(1002, "Vikash", 9812, "Consultant");
        let empObj2 = new Employee(1003, "Amresh", 6661, "Sr Consultant");
        let empObj3 = new Employee(1001, "Uma", 10000, "Sr Manager");
        let empObj4 = new Employee(1000, "Vaishali", 9123, "Manager");

        //this line indicates that Creating Set Object to Employee Class
        this.listOfEmpsObject = new Set();

        // Section-2 a-Answer:Adding Employee objects to set
        this.listOfEmpsObject.add(empObj1);
        this.listOfEmpsObject.add(empObj2);
        this.listOfEmpsObject.add(empObj3);
        this.listOfEmpsObject.add(empObj4);
    }

    //function for Sorting Employee Details By empId
     sortByEmpId(){
         console.log("After Sorting In Ascending Order"+"Order By Employee Id");
         let sortedSet=Array.from(this.listOfEmpsObject).sort((e1,e2)=>e1.empId-e2.empId);
         return sortedSet;
     }

     //function getAllEmployees()
     getAllEmployees(){
        return this.listOfEmpsObject;
     }

     //function to delete Employee Details Based On Employee Id
     deleteByEmpId(id){
         let deletedEmployee=Array.from(this.listOfEmpsObject).find(e => e.empId==id);
         this.listOfEmpsObject.delete(deletedEmployee);
         return this.listOfEmpsObject;
     }
}//End of EmployeeUtility class

//Declaring Object to the Employeeutility class
let utilityObj; 

//Menu For Showing Different options
console.log("MENU");
console.log("1-Add Employees");
console.log("2-Show employee Details");
console.log("3-Sort By Employee Id");
console.log("4-Delete By Employee Id");
console.log("0-exit");

//Displaying Operations Using Switch case
let choiceYN="N";
do{
    let choice=parseInt(prompt('Your Choice ',0));
    switch(choice){
        case 1:{
            //adding Employee list By Initializing Object to EmployeeUtility Class
            utilityObj=new EmployeeUtility();
            console.log("Employee List Is Prepared");
        }break;
        case 2:{
            //Printing the Details Of Employees
            let listOfEmpsObject=utilityObj.getAllEmployees();
            for(let emp of listOfEmpsObject){
                console.log(emp.printDetails());
            }

        }break;
        case 3:{
            //Section-2 b-Answer:Printing the Data in Ascending Order Of Emp Id
            let sortedListOfEmpsObject=utilityObj.sortByEmpId();
            for(let emp of sortedListOfEmpsObject){
                console.log(emp.printDetails());
            }
        }break;
        case 4:{
            //Section-2 c-Answer:Deleting Employee details based on Emp Id
            console.log('Current List Of employees');
            let listOfEmpsObject=utilityObj.getAllEmployees();
            for(let emp of listOfEmpsObject){
                console.log(emp.printDetails());
            }
            let id=parseInt(prompt('Employee Id you want to delete',0));
            let result=confirm("Are you Sure You Want To Delete");
            if(result){
                //Calling deleteByEmpId() function
                let newEmpObject=utilityObj.deleteByEmpId(id);
                console.log("\nAfter Deleting "+id+"employee Details Are:");
                if(newEmpObject!=null){
                    for(emp of newEmpObject){
                        console.log(emp.printDetails());
                    }
                }
                else{
                    console.log("Employee Id Does Not Exist");
                }

            }
        }break;
        case 0:{
            console.log("\n\n\n\t\tThank You");
        }break;
        default:{
            console.log("Invalid Choice");
        }
    }//End of Switch Case
   choiceYN=prompt("Do You Wants ToContinue",0);
}while(choiceYN==='Y'||choiceYN==='y');

//Section-2 d0-Answer:Inheritance Using_proto_
let empObj=new Employee();
let logObj=new Login();
empObj._proto_=logObj;
console.log("output obtained using _proto_");
console.log("loginObj.getLogin():"+logObj.getLogin());
console.log("empObj.getLogin():"+empObj.getLogin());
//inheritance using object.create();
let empobject=new Employee();
let logObject=new Login();
empObject=Object.create(logObject);
console.log("empObject.getLogin():"+Employee.prototype.getLogin());
